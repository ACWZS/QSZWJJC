using Photon.Pun;
using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

public class GameNetworkManager : MonoBehaviourPunCallbacks
{
    public static GameNetworkManager Instance { get; private set; }  // ���ӵ�������

    public GameObject playerPrefab;
    public Transform[] spawnPoints;
    private bool spawned = false;

    void Awake()
    {
        // ����ģʽ��ȷ��ֻ��һ��ʵ��
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
        DontDestroyOnLoad(gameObject);
    }

    void Start()
    {
        //Debug.Log("GameNetworkManager Start: IsConnected=" + PhotonNetwork.IsConnected + ", InRoom=" + PhotonNetwork.InRoom);
        if (PhotonNetwork.IsConnected && PhotonNetwork.InRoom && !spawned)
        {
            SpawnPlayer();
        }
    }

    public override void OnJoinedRoom()
    {
        base.OnJoinedRoom();
        Debug.Log("OnJoinedRoom: ���뷿�䣬׼���������");
        if (!spawned)
        {
            SpawnPlayer();
        }
    }

    private void SpawnPlayer()
    {
        if (spawned) return;
        if (spawnPoints == null || spawnPoints.Length == 0)
        {
            Debug.LogError("δ���ó����㣡");
            return;
        }

        int spawnIndex = PhotonNetwork.LocalPlayer.ActorNumber % spawnPoints.Length;
        Vector3 spawnPos = spawnPoints[spawnIndex].position;
        Quaternion spawnRot = spawnPoints[spawnIndex].rotation;

        GameObject playerObj = PhotonNetwork.Instantiate(playerPrefab.name, spawnPos, spawnRot);
        spawned = true;
    }

    public override void OnLeftRoom()
    {
        base.OnLeftRoom();
        //Debug.Log("=== GameNetworkManager.OnLeftRoom ������ ===");

        var playerData = PlayerDataManager.Instance?.CurrentPlayerData;
        if (playerData == null || !playerData.ContainsKey("_id"))
        {
            Debug.LogError("�������δ�������޷����»�ɱ��");
            return;
        }

        int kills = PlayerMain.LastMatchKills;
        if (kills == 0)
        {
            //Debug.Log("���ֻ�ɱ��Ϊ0���������");
            return;
        }

        StartCoroutine(UpdateKillCountCoroutine(kills));
    }

    private IEnumerator UpdateKillCountCoroutine(int kills)
    {
        string docId = PlayerDataManager.Instance.CurrentPlayerData["_id"].ToString();
        int currentTotal = 0;
        if (PlayerDataManager.Instance.CurrentPlayerData.ContainsKey("killCount"))
            currentTotal = Convert.ToInt32(PlayerDataManager.Instance.CurrentPlayerData["killCount"]);
        int newTotal = currentTotal + kills;

        //Debug.Log($"׼�����»�ɱ�������� {kills}����ǰ�� {currentTotal}������ {newTotal}");

        bool success = false;
        yield return CloudBaseHttpClient.Update(
            "players",
            docId,
            new Dictionary<string, object> { { "killCount", newTotal } },
            (s, response) => {
                success = s;
                //Debug.Log($"���»ص� success={s}, response={response}");
            }
        );

        if (success)
        {
            PlayerDataManager.Instance.CurrentPlayerData["killCount"] = newTotal;
            //Debug.Log($"��ɱ���Ѹ����� {newTotal}");
        }
        else
        {
            Debug.LogError("��ɱ������ʧ��");
        }

        PlayerMain.ResetLastMatchKills();
    }
}