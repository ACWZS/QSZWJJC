using UnityEngine;
using System.Collections.Generic;
using Photon.Pun;

public static class PlayerAiming
{
    // ��ȡ�����������������
    public static Vector3 GetAttackDirection()
    {
        var player = PlayerMain.Instance;
        if (player == null) return Vector3.forward;

        bool useMobile = false;
#if UNITY_EDITOR
        useMobile = player.simulateMobileInEditor;
#else
        useMobile = (Application.platform == RuntimePlatform.Android || Application.platform == RuntimePlatform.IPhonePlayer);
#endif

        // ������׼���ȣ��ƶ����϶���׼�ߣ�
        if (useMobile && player.IsAiming && player.AimDirection.magnitude > 0f)
            return player.AimDirection;

        // �Զ���׼��������ĵ��ˣ��� autoAimRange ���ƣ�
        Transform nearest = GetNearestEnemy(player.autoAimRange);
        if (nearest != null)
        {
            Vector3 dir = (nearest.position - player.transform.position).normalized;
            return dir;
        }

        Vector3 forward = player.transform.forward;
        forward.y = 0;
        if (forward.magnitude < 0.01f) forward = Vector3.forward;
        return forward.normalized;
    }

    // ��ȡĿ����ת�����ڽ�ɫת��
    public static Quaternion GetTargetRotation()
    {
        var player = PlayerMain.Instance;
        if (player == null) return Quaternion.identity;

        if (player.IsInContinuousAttack || player.IsSingleShotPending)
        {
            Vector3 attackDir = GetAttackDirection();
            if (attackDir.magnitude > 0.1f)
            {
                Vector3 horizontalDir = attackDir;
                horizontalDir.y = 0;
                if (horizontalDir.magnitude > 0.1f)
                    return Quaternion.LookRotation(horizontalDir);
            }
        }
        return player.transform.rotation;
    }

    // ������׼����������ǰ��׼�����򸽽��ĵ��˷���������
    public static Vector3 GetAimAssistedDirection(Vector3 currentDirection, Vector3 playerPos, float radius, float angle, float smooth)
    {
        Transform bestTarget = GetBestTargetInCone(currentDirection, playerPos, radius, angle);
        if (bestTarget == null)
            return currentDirection;

        Vector3 targetDir = (bestTarget.position - playerPos).normalized;
        Vector3 newDir = Vector3.Slerp(currentDirection, targetDir, 1f - smooth);
        return newDir.normalized;
    }

    // ��ȡ׶�η�Χ�ڵ���ѵ��ˣ����ڸ�����׼��
    private static Transform GetBestTargetInCone(Vector3 direction, Vector3 playerPos, float radius, float angle)
    {
        List<Transform> enemies = GetAllEnemies();
        Transform best = null;
        float bestScore = 0f;

        foreach (Transform enemy in enemies)
        {
            if (enemy == null) continue;
            Vector3 toEnemy = enemy.position - playerPos;
            float dist = toEnemy.magnitude;
            if (dist > radius) continue;

            float angleToEnemy = Vector3.Angle(direction, toEnemy.normalized);
            if (angleToEnemy > angle) continue;

            float score = (1f - angleToEnemy / angle) * (1f - dist / radius);
            if (score > bestScore)
            {
                bestScore = score;
                best = enemy;
            }
        }
        return best;
    }

    // ��ȡ����ĵ��ˣ������Զ���׼��
    public static Transform GetNearestEnemy(float maxRange = float.MaxValue)
    {
        var player = PlayerMain.Instance;
        if (player == null) return null;

        List<Transform> enemies = GetAllEnemies();
        float nearestDist = maxRange;
        Transform nearest = null;
        Vector3 myPos = player.transform.position;

        foreach (Transform enemy in enemies)
        {
            if (enemy == null) continue;
            float dist = Vector3.Distance(myPos, enemy.position);
            if (dist <= nearestDist)
            {
                nearestDist = dist;
                nearest = enemy;
            }
        }
        return nearest;
    }

    // ��ȡ����Ǳ�ڵĵ��ˣ�AI ���� + ������ң�
    private static List<Transform> GetAllEnemies()
    {
        List<Transform> enemies = new List<Transform>();

        // 1. ��ȡ���б�ǩΪ "Enemy" �� AI ����
        GameObject[] aiEnemies = GameObject.FindGameObjectsWithTag("Enemy");
        foreach (GameObject enemy in aiEnemies)
        {
            if (enemy != null)
                enemies.Add(enemy.transform);
        }

        // 2. ��ȡ���б�ǩΪ "Player" ����ң��ų��������
        GameObject[] players = GameObject.FindGameObjectsWithTag("Player");
        foreach (GameObject player in players)
        {
            if (player == null) continue;
            // �ų��������
            if (PlayerMain.Instance != null && player == PlayerMain.Instance.gameObject)
                continue;
            // ����ģʽ�£��ų�ͬ�������ң����δ���ж���ϵͳ�������������жϣ�
            // ��ʱ���������������Ϊ����
            enemies.Add(player.transform);
        }

        return enemies;
    }

    // ������׼�ߣ��ƶ��ˣ�
    public static void UpdateAiming()
    {
        var player = PlayerMain.Instance;
        if (player == null) return;

        bool useMobile = false;
#if UNITY_EDITOR
        useMobile = player.simulateMobileInEditor;
#else
        useMobile = (Application.platform == RuntimePlatform.Android || Application.platform == RuntimePlatform.IPhonePlayer);
#endif

        if (useMobile && player.IsLongPressConfirmed && player.aimLine != null)
        {
            player.aimLine.enabled = true;
            Vector3 startPos = player.transform.position + player.aimLineOffset;
            Vector3 endPos = startPos + player.AimDirection * player.aimLineDistance;
            player.aimLine.SetPosition(0, startPos);
            player.aimLine.SetPosition(1, endPos);
        }
        else if (player.aimLine != null)
        {
            player.aimLine.enabled = false;
        }
    }

    // ���ݾɵ��õ����أ��޲����汾��
    public static Transform GetNearestEnemy()
    {
        var player = PlayerMain.Instance;
        if (player == null) return null;
        return GetNearestEnemy(player.autoAimRange);
    }
}