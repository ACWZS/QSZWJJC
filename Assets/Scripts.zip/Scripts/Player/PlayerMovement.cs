using UnityEngine;

public static class PlayerMovement
{

    public static void UpdateMovement()
    {
        var player = PlayerMain.Instance;
        if (player == null) return;
        // ���������δ���ã�ֱ�ӷ��أ�����������
        if (player.Controller == null || !player.Controller.enabled) return;

        // ��ȡ���룺����ʹ�� UI ҡ�ˣ���ҡ����������ʹ�ü���
        float x = player._moveInput.x;
        float z = player._moveInput.y;
        if (Mathf.Abs(x) < 0.1f && Mathf.Abs(z) < 0.1f)
        {
            x = Input.GetAxis("Horizontal");
            z = Input.GetAxis("Vertical");
        }

        // �����Է���
        Vector3 moveDirection = Vector3.zero;
        if (player.cameraTransform != null)
        {
            Vector3 cameraForward = player.cameraTransform.forward;
            cameraForward.y = 0;
            cameraForward.Normalize();
            Vector3 cameraRight = player.cameraTransform.right;
            cameraRight.y = 0;
            cameraRight.Normalize();
            moveDirection = cameraRight * x + cameraForward * z;
            if (moveDirection.magnitude > 1f) moveDirection.Normalize();
        }

        // �ƶ�
        player.Controller.Move(moveDirection * player.speed * Time.deltaTime);

        // ���߶���
        if (player.Animator != null)
            player.Animator.SetBool("isWalking", moveDirection.magnitude > 0.1f);

        // ��Ծ��ͬʱ֧�� UI ��ť�ͼ��̿ո�
        bool jumpInput = player.JumpPressed || Input.GetButtonDown("Jump");
        if (jumpInput && player.IsGrounded)
        {
            player.Velocity = new Vector3(player.Velocity.x, Mathf.Sqrt(player.jumpHeight * -2f * PlayerMain.Gravity), player.Velocity.z);
            player.JumpPressed = false;
        }

        // ����
        player.Velocity += Vector3.up * PlayerMain.Gravity * Time.deltaTime;
        player.Controller.Move(player.Velocity * Time.deltaTime);

        // ��ת�����ڷǹ���״̬�����ƶ��������
        if (!player.IsInContinuousAttack && !player.IsSingleShotPending)
        {
            if (moveDirection.magnitude > 0.1f)
            {
                Quaternion targetRot = Quaternion.LookRotation(moveDirection);
                player.transform.rotation = Quaternion.Slerp(player.transform.rotation, targetRot, player.rotationSpeed * Time.deltaTime);
            }
        }
    }
}