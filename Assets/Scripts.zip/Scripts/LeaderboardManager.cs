using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.Collections;
using System.Collections.Generic;

public class LeaderboardManager : MonoBehaviour
{
    public GameObject leaderboardPanel;
    public Transform contentParent;
    public GameObject itemPrefab;            // Ԥ�����ϱ������ LeaderboardItem �ű�
    public Button refreshButton;

    private void Start()
    {
        leaderboardPanel.SetActive(false);
        if (refreshButton != null)
            refreshButton.onClick.AddListener(() => StartCoroutine(RefreshLeaderboard()));
    }

    public void ShowLeaderboard()
    {
        leaderboardPanel.SetActive(true);
        StartCoroutine(RefreshLeaderboard());
    }

    public void CloseLeaderboard()
    {
        leaderboardPanel.SetActive(false);
    }

    private IEnumerator RefreshLeaderboard()
    {
        // ����б�
        foreach (Transform child in contentParent)
            Destroy(child.gameObject);

        const int pageSize = 100; // ÿҳ�������ɵ��������1000
        int currentSkip = 0;
        List<Dictionary<string, object>> allPlayers = new List<Dictionary<string, object>>();

        // ѭ����ҳ��ȡ
        while (true)
        {
            bool querySuccess = false;
            List<Dictionary<string, object>> pageResult = null;
            yield return CloudBaseHttpClient.QueryWithPage("players", null, currentSkip, pageSize, (success, result) =>
            {
                querySuccess = success;
                pageResult = result;
            });

            if (!querySuccess || pageResult == null || pageResult.Count == 0)
                break;

            allPlayers.AddRange(pageResult);
            currentSkip += pageSize;
            yield return null;
        }

        if (allPlayers.Count == 0)
        {
            Debug.LogWarning("δ�ܻ�ȡ���а�����");
            yield break;
        }

        // ����ɱ����������
        allPlayers.Sort((a, b) =>
        {
            long killA = a.ContainsKey("killCount") ? System.Convert.ToInt64(a["killCount"]) : 0;
            long killB = b.ContainsKey("killCount") ? System.Convert.ToInt64(b["killCount"]) : 0;
            return killB.CompareTo(killA);
        });

        int rank = 1;
        foreach (var player in allPlayers)
        {
            GameObject item = Instantiate(itemPrefab, contentParent);
            LeaderboardItem itemScript = item.GetComponent<LeaderboardItem>();
            if (itemScript == null)
            {
                Debug.LogError("Ԥ����ȱ�� LeaderboardItem �����");
                continue;
            }

            string playerId = player.ContainsKey("playerId") ? player["playerId"].ToString() : "?";
            string playerName = player.ContainsKey("playerName") ? player["playerName"].ToString() : "?";
            long killCount = player.ContainsKey("killCount") ? System.Convert.ToInt64(player["killCount"]) : 0;

            itemScript.SetData(rank, playerId, playerName, killCount);
            rank++;
        }
    }
}