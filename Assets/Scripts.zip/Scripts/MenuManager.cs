using UnityEngine;
using UnityEngine.SceneManagement;

public class MenuManager : MonoBehaviour
{
    public void Exit()
    {
        SceneManager.LoadScene("MainMenu");
    }

    public void StartTest()
    {
        SceneManager.LoadScene("Arena");
    }

    public void JoinArena()
    {
        SceneManager.LoadScene("ArenaLobby");
    }

    public void ExitLogin()
    {
        // �������ĵ�¼ƾ�ݣ��´ν����¼���潫�����Զ���¼
        PlayerPrefs.DeleteKey("SavedUsername");
        PlayerPrefs.DeleteKey("SavedPassword");
        PlayerPrefs.Save();

        SceneManager.LoadScene("Login");
    }
}