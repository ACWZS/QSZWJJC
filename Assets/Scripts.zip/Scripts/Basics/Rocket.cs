using UnityEngine;
using Photon.Pun;

public class Rocket : MonoBehaviour
{
    public float speed = 20f;
    public float lifeTime = 5f;
    public float explosionRadius = 1f;          // ����Χ������
    public float explosionDamage = 30f;         // �ɵ������ñ�ը�˺�
    public GameObject explosionEffect;

    private GameObject shooterRoot;
    private Vector3 direction;

    public void Initialize(GameObject shooter, Vector3 dir)
    {
        shooterRoot = shooter;
        direction = dir.normalized;
    }

    void Start()
    {
        if (direction == Vector3.zero)
        {
            //Debug.LogWarning("Rocket direction is zero, using default forward");
            direction = transform.forward;
        }
        if (speed <= 0) speed = 20f;
        transform.rotation = Quaternion.LookRotation(direction);
        Destroy(gameObject, lifeTime);
    }

    void Update()
    {
        transform.Translate(direction * speed * Time.deltaTime, Space.World);
    }

    void OnTriggerEnter(Collider other)
    {
        // ���Կ�ǹ������
        if (shooterRoot != null && other.transform.root.gameObject == shooterRoot)
            return;

        // ��ը
        Explode();

        // ���ٻ����
        Destroy(gameObject);
    }

    private void Explode()
    {
        if (explosionEffect != null)
            Instantiate(explosionEffect, transform.position, Quaternion.identity);

        // ֻ������ߵı��ؿͻ��˲�����˺�
        PhotonView shooterPV = shooterRoot.GetComponent<PhotonView>();
        if (shooterPV == null || !shooterPV.IsMine)
        {
            Destroy(gameObject);
            return;
        }

        Collider[] colliders = Physics.OverlapSphere(transform.position, explosionRadius);
        foreach (Collider col in colliders)
        {
            if (col.CompareTag("Player") || col.CompareTag("Enemy"))
            {
                Health targetHealth = col.GetComponent<Health>();
                if (targetHealth != null)
                {
                    float distance = Vector3.Distance(transform.position, col.transform.position);
                    float damageMultiplier = 1f - (distance / explosionRadius);
                    float finalDamage = explosionDamage * Mathf.Max(0.1f, damageMultiplier);
                    targetHealth.TakeDamage(finalDamage, shooterRoot);
                }
            }
        }
    }
}