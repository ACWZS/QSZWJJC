using UnityEngine;
using System.Collections;
using Photon.Pun;

public class EnemyAI : MonoBehaviour
{
    [Header("Ŀ��")]
    public Transform player;

    [Header("�ƶ�����")]
    public float moveSpeed = 1f;
    public float rotationSpeed = 10f;
    public float chaseRange = 2f;
    public float attackRange = 1f;

    [Header("���")]
    public Gun enemyGun;                 // ����ʹ�õ�ǹе���

    [Header("ǹеģ��")]
    public GameObject gunModel;

    [Header("����")]
    public Transform respawnPoint;
    public float respawnDelay = 3f;

    // �������
    private CharacterController controller;
    private Animator animator;
    private Vector3 velocity;
    private bool isGrounded;
    private Health health;
    private PlayerStats stats;          // �������������
    private HealthBarWorld healthBar;
    private bool isDead = false;

    void Start()
    {
        controller = GetComponent<CharacterController>();
        animator = GetComponent<Animator>();
        health = GetComponent<Health>();
        stats = GetComponent<PlayerStats>();   // ��ȡ PlayerStats
        healthBar = GetComponentInChildren<HealthBarWorld>();

        if (health != null)
            health.OnDeath.AddListener(Die);

        if (player == null)
        {
            GameObject playerObj = GameObject.FindGameObjectWithTag("Player");
            if (playerObj != null) player = playerObj.transform;
            else Debug.LogWarning("δ�ҵ���ң�AI �������ж�");
        }

        // ��ʼ��������ȷ��ǹе֪���Լ��������ǵ�ǰ AI
        if (enemyGun != null)
        {
            // ����ǹе�� PhotonView ���ã����������ģʽ��
            // ��һ���� Gun.Start �л��Զ��Ӹ�������ң�����ʽ���ø���ȫ
            enemyGun.transform.root.TryGetComponent<PhotonView>(out var pv);
        }

        if (gunModel != null) gunModel.SetActive(false);
    }

    void Update()
    {
        if (player == null || isDead) return;

        // ������
        isGrounded = controller.isGrounded;
        float distanceToPlayer = Vector3.Distance(transform.position, player.position);

        if (distanceToPlayer <= attackRange)
        {
            Attack();
        }
        else if (distanceToPlayer <= chaseRange)
        {
            Chase();
        }
        else
        {
            Idle();
        }

        // Ӧ������
        if (isGrounded && velocity.y < 0) velocity.y = -2f;
        velocity.y += Physics.gravity.y * Time.deltaTime;
        controller.Move(velocity * Time.deltaTime);

        // ���������
        if (transform.position.y < -10f)
        {
            Die();
        }
    }

    void Chase()
    {
        Vector3 direction = (player.position - transform.position).normalized;
        direction.y = 0;
        if (direction.magnitude > 0.1f)
        {
            Quaternion targetRotation = Quaternion.LookRotation(direction);
            transform.rotation = Quaternion.Slerp(transform.rotation, targetRotation, rotationSpeed * Time.deltaTime);
            controller.Move(direction * moveSpeed * Time.deltaTime);
        }
        SetAnimation(true, false);
        ShowGunModel(false);
    }

    void Attack()
    {
        // �������
        Vector3 direction = (player.position - transform.position).normalized;
        direction.y = 0;
        if (direction.magnitude > 0.1f)
        {
            Quaternion targetRotation = Quaternion.LookRotation(direction);
            transform.rotation = Quaternion.Slerp(transform.rotation, targetRotation, rotationSpeed * Time.deltaTime);
        }

        // �����ʹ��ǹе�� TryFire �����������Զ������ӵ����ɺ��˺���Դ
        if (enemyGun != null)
        {
            enemyGun.TryFire();
        }

        SetAnimation(false, true);
        ShowGunModel(true);
    }

    void Idle()
    {
        SetAnimation(false, false);
        ShowGunModel(false);
    }

    void SetAnimation(bool isWalking, bool isAttacking)
    {
        if (animator != null)
        {
            animator.SetBool("isWalking", isWalking);
            animator.SetBool("isAttacking", isAttacking);
        }
    }

    void ShowGunModel(bool show)
    {
        if (gunModel != null && gunModel.activeSelf != show)
            gunModel.SetActive(show);
    }

    void Die()
    {
        if (isDead) return;
        isDead = true;

        if (controller != null) controller.enabled = false;
        if (animator != null) animator.enabled = false;
        if (enemyGun != null) enemyGun.enabled = false;
        ShowGunModel(false);

        velocity = Vector3.zero;
        StartCoroutine(RespawnCoroutine());
    }

    IEnumerator RespawnCoroutine()
    {
        yield return new WaitForSeconds(respawnDelay);

        if (respawnPoint != null)
        {
            transform.position = respawnPoint.position;
            transform.rotation = respawnPoint.rotation;
        }

        // ʹ�� Health.ResetHealth ������Ѫ����������� PlayerStats.ResetStats
        if (health != null)
            health.ResetHealth();

        // �ֶ�����Ѫ��
        if (healthBar != null && stats != null)
            healthBar.UpdateHealthBar(stats.CurrentHealth);

        if (controller != null) controller.enabled = true;
        if (animator != null) animator.enabled = true;
        if (enemyGun != null) enemyGun.enabled = true;

        isDead = false;
        velocity = Vector3.zero;
        SetAnimation(false, false);
    }
}