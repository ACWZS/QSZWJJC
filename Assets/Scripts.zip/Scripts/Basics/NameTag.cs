using UnityEngine;
using TMPro;
using Photon.Pun;

public class NameTag : MonoBehaviour
{
    [Header("����Ŀ��")]
    public Transform target;
    public Vector3 offset = new Vector3(0, 0.8f, 0);

    [Header("UI ���")]
    public TextMeshProUGUI nameText;

    private Camera mainCamera;
    private string displayName;

    void Start()
    {
        mainCamera = Camera.main;
        if (mainCamera == null)
            Debug.LogError("δ�ҵ��������");

        if (target == null)
            target = transform.parent;

        // ��ȡ�������
        displayName = GetPlayerName();
        if (nameText != null)
            nameText.text = displayName;
    }

    void LateUpdate()
    {
        if (target != null && mainCamera != null)
        {
            transform.LookAt(mainCamera.transform);
            transform.Rotate(0, 180, 0);
            transform.position = target.position + offset;
        }
    }

    private string GetPlayerName()
    {
        // 1. ����ģʽ���� PhotonView ��ȡ
        PhotonView pv = GetComponentInParent<PhotonView>();
        if (pv != null && pv.Owner != null && !string.IsNullOrEmpty(pv.Owner.NickName))
            return pv.Owner.NickName;

        // 2. ����ģʽ���� PhotonNetwork.NickName ��ȡ����¼ʱ�����ã�
        if (!string.IsNullOrEmpty(PhotonNetwork.NickName))
            return PhotonNetwork.NickName;

        // 3. ����ģʽ���� PlayerDataManager ��ȡ
        if (PlayerDataManager.Instance != null && PlayerDataManager.Instance.CurrentPlayerData != null)
        {
            if (PlayerDataManager.Instance.CurrentPlayerData.ContainsKey("playerName"))
                return PlayerDataManager.Instance.CurrentPlayerData["playerName"].ToString();
        }

        // 4. Ĭ������
        return "Player";
    }
}