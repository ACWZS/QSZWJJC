using UnityEngine;

[CreateAssetMenu(fileName = "NewWeapon", menuName = "Weapon/WeaponData")]
public class WeaponData : ScriptableObject
{
    [Header("Basic Info")]
    public string weaponName;
    public WeaponType type;

    [Header("Weapon Stats")]
    public float damage = 20f;
    public float fireRate = 0.5f;          // ���������룩
    public float reloadTime = 2f;           // ����ʱ�䣨�룩
    public int maxAmmo = 30;                // ��������
    public int totalAmmo = 30;              // �ܵ�ҩ�����������ڣ�
    public GameObject bulletPrefab;

    [Header("Shotgun")]
    public int pelletCount = 1;
    public float spreadAngle = 0f;

    [Header("Audio")]
    public AudioClip shootSound;
}

public enum WeaponType
{
    Pistol,
    ShotgunPistol,
    Shotgun,
    Sniper,
    RocketLauncher
}