using UnityEngine;
using UnityEngine.UI;

public class HealthBarWorld : MonoBehaviour
{
    [Header("Ŀ��")]
    public Transform target;
    public Vector3 offset = new Vector3(0, 0.4f, 0);

    [Header("UI ���")]
    public Image fillImage;

    private Health health;
    private PlayerStats stats;        // ��������
    private Camera mainCamera;

    void Start()
    {
        mainCamera = Camera.main;
        if (mainCamera == null)
            Debug.LogError("δ�ҵ��������");

        if (target != null)
        {
            health = target.GetComponent<Health>();
            stats = target.GetComponent<PlayerStats>();   // ��ȡ PlayerStats

            if (health == null)
                Debug.LogError($"Ŀ�� {target.name} û�� Health �����");
            else if (stats == null)
                Debug.LogError($"Ŀ�� {target.name} û�� PlayerStats �����");
            else
            {
                // ���Ĵ��������¼�
                health.OnHealthChanged.AddListener(UpdateHealthBar);
                // ��ʼ����
                UpdateHealthBar(stats.CurrentHealth);
            }
        }
        else
        {
            Debug.LogError("δָ������Ŀ�꣡");
        }
    }

    void LateUpdate()
    {
        if (target != null && mainCamera != null)
        {
            transform.LookAt(mainCamera.transform);
            transform.Rotate(0, 180, 0);
            transform.position = target.position + offset;
        }
    }

    // �޸ģ����� float ����
    public void UpdateHealthBar(float currentHealth)
    {
        if (stats != null && fillImage != null)
        {
            fillImage.fillAmount = currentHealth / stats.MaxHealth;
        }
    }

    // �޲ΰ汾�������ݣ������ᱻ���ã�
    public void UpdateHealthBar()
    {
        if (stats != null)
            UpdateHealthBar(stats.CurrentHealth);
    }

    void OnDestroy()
    {
        if (health != null)
            health.OnHealthChanged.RemoveListener(UpdateHealthBar);
    }
}